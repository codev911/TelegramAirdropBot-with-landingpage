<?php
  session_start();
  error_reporting(0);
ini_set('display_errors', 0);
  require_once('koneksi.php');
  $datareff = $_SESSION['reff_id'];
  $select = "SELECT * FROM user WHERE reff_id='$datareff'";
  $dataparse = mysqli_query($conn,$select);
  $datafetch = mysqli_fetch_array($dataparse);
  $select2 = "SELECT * FROM user WHERE reffered_by='$datareff'";
  $dataparse2 = mysqli_query($conn,$select2);
  $datafetch2 = mysqli_num_rows($dataparse2);
?>
<!DOCTYPE html>
<html lang="en">

<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">

  <title>Levyte airdrop - Dashboard!</title>
  <link href="img/favicon.ico" rel="icon">

  <!-- Bootstrap core CSS -->
  <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

  <!-- Custom fonts for this template -->
  <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet">
  <link href="vendor/simple-line-icons/css/simple-line-icons.css" rel="stylesheet" type="text/css">
  <link href="https://fonts.googleapis.com/css?family=Lato:300,400,700,300italic,400italic,700italic" rel="stylesheet" type="text/css">

  <!-- Custom styles for this template -->
  <link href="css/landing-page.css" rel="stylesheet">

</head>

<body>
  <!-- Masthead -->
  <header class="masthead text-white text-center">
    <div class="overlay"></div>
    <div class="container">
      <div class="row">
        <div class="col-xl-8 mx-auto">
            <h1 class="mb-5">Complete and Get 22222 LEVT or more</h1>
            <div class="form-row">
              <div class="col-12 text-left">
                <h5>1. Join to <a class="text-warning" href="https://t.me/LevyteProject">Telegram group</a> and <a class="text-warning" href="https://t.me/ProjectLevyte">Telegram channel</a>.</h5>
              </div>
              <div class="col-12 text-left">
                <h5>2. Like, follow and share our <a class="text-warning" href="https://www.facebook.com/LEVT-Levyte-Token-Foundation-358208911574632/">Facebook</a>, <a class="text-warning" href="https://twitter.com/account/access">Twitter</a> and <a class="text-warning" href="https://medium.com/@Project_Levyte">Medium</a>.</h5>
              </div>
              <div class="col-6 col-md-4 mb-2 mb-md-0 text-left">
                <h5>3. Copy this confirm code: </h5>
              </div>
              <div class="col-6 col-md-4">
                <input type="text" name="confirm" class="form-control form-control-lg" value="/confirm <?php echo $datareff; ?>">
              </div>
              <div class="col-12 text-left">
                <h5>4. Paste on telegram group for confirmation.</h5>
              </div>
              <div class="col-12 text-left">
                <h5>5. Done.</h5>
              </div>
            </div><br>
            <div class="row">
              <div class="col-6">
                <h3>Total Earned</h3>
              </div>
              <div class="col-6">
                <h3>Total Reffered</h3>
              </div>
              <div class="col-6">
                <h3 class="mb-5"><?php echo $datafetch['earned']; ?></h3>
              </div>
              <div class="col-6">
                <h3 class="mb-5"><?php echo $datafetch2; ?></h3>
              </div>
              <div class="col-12">
                <h4>Refferal link </h4>
                <input type="text" name="confirm" class="form-control form-control-lg" value="https://airdrop.levyte.com/?id=<?php echo $datareff; ?>">
              </div>
            </div>
        </div>
      </div>
    </div>
  </header>

  <!-- Bootstrap core JavaScript -->
  <script src="vendor/jquery/jquery.min.js"></script>
  <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

</body>

</html>
