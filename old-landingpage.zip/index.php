<?php
  session_start();
  error_reporting(0);
  ini_set('display_errors', 0);
  require_once('koneksi.php');
  $datareff = $_GET['id'];
  if(isset($_SESSION['reff_id'])){
      header('location: dashboard');
  }
  function randomid($long){
    $char = "1234567890abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
    $string = "";
    for($i = 0; $i < $long; $i++){
        $pos = rand(0, strlen($char)-1);
        $string .= $char{$pos};
    }
        return $string;
  }

  function clean($string) {
    $string = str_replace(' ', '-', $string);
    return preg_replace('/[^A-Za-z0-9\-]/', '', $string);
  }

  $datareff = clean($datareff);
  $getreff = $datareff;
  echo $getreff."<br>";
  $selector = "SELECT * FROM user WHERE reff_id='$getreff'";
  $checkr = mysqli_query($conn,$selector);
  $checkrow = mysqli_num_rows($checkr);
  echo $checkrow;
  if($checkrow == 0){
        $getreff = "SYSTEM";
  }else{
        $getreff = $datareff;
  }

  $newreff = randomid(8);
  $ip = $_SERVER['REMOTE_ADDR'];

  $uniqueid;
  $cookie_name = "uniquebrowser";
  $cookie_value = randomid(25);

  if(!isset($_COOKIE[$cookie_name])) {
      setcookie($cookie_name, $cookie_value, time() + (86400 * 30), "/");
      $uniqueid = $_COOKIE[$cookie_name];
  } else {
      $uniqueid = $_COOKIE[$cookie_name];
  }

  if(isset($_POST['reg'])){
    $erc20 = $_POST['erc20'];
    $select2 = "SELECT * FROM user WHERE erc20='$erc20'";
    $check2 = mysqli_query($conn,$select2);
    $getrow = mysqli_num_rows($check2);
    if($_POST['erc20'] == NULL){
        header("location: /");
    }else if($getrow == 0){
      $query = "INSERT INTO user VALUES('$newreff','$erc20','$ip','$uniqueid',CURRENT_TIMESTAMP,0,'$getreff','no')";
      mysqli_query($conn,$query);
      $_SESSION['reff_id'] = $newreff;
      header('location: dashboard');
    }else{
      $datareff = mysqli_fetch_array($check2);
      $_SESSION['reff_id'] = $datareff['reff_id'];
      header('location: dashboard');
    }
  }
  
?>
<!DOCTYPE html>
<html lang="en">

<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">

  <title>Levyte airdrop - Get 22222 LEVT now!</title>
  
  <link href="img/favicon.ico" rel="icon">

  <!-- Bootstrap core CSS -->
  <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

  <!-- Custom fonts for this template -->
  <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet">
  <link href="vendor/simple-line-icons/css/simple-line-icons.css" rel="stylesheet" type="text/css">
  <link href="https://fonts.googleapis.com/css?family=Lato:300,400,700,300italic,400italic,700italic" rel="stylesheet" type="text/css">

  <!-- Custom styles for this template -->
  <link href="css/landing-page.css" rel="stylesheet">

</head>

<body>
  <!-- Masthead -->
  <header class="masthead text-white text-center">
    <div class="overlay"></div>
    <div class="container">
      <div class="row">
        <div class="col-xl-9 mx-auto">
          <a href="https://levyte.com"><img src="img/logo.png" width="50%" hight="auto"/></a>
          <h1 class="mb-5">Join Levyte Airdrop and Get 22222 LEVT</h1>
        </div>
        <div class="col-md-10 col-lg-8 col-xl-7 mx-auto">
          <form action="" method="POST">
            <div class="form-row">
              <div class="col-12 col-md-9 mb-2 mb-md-0">
                <input type="text" name="erc20" class="form-control form-control-lg" placeholder="Enter your ERC20 Wallet...">
              </div>
              <div class="col-12 col-md-3">
                <button type="submit" name="reg" class="btn btn-block btn-lg btn-primary">Get Started</button>
              </div>
            </div>
          </form>
        </div>
      </div>
    </div>
  </header>

  <!-- Bootstrap core JavaScript -->
  <script src="vendor/jquery/jquery.min.js"></script>
  <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

</body>

</html>
