<?php
    require_once('koneksi.php');
    error_reporting(0);
    ini_set('display_errors', 0);
	
	$query = "SELECT * FROM activation";
    $query2 = mysqli_query($conn, $query);
    $i=0;
    while($data = mysqli_fetch_array($query2)){
        $member[$i] = $data['telegram_id'];
        $i++;
    }
    
    // echo count($member);
    
    for($i=450; $i<500; $i++){
        $website[$i] = "https://api.telegram.org/bot772748111:AAGYJokeHu0OFCRVFn2Wt6g8STMvCC62Lmg/getChatMember?chat_id=-1001270693075&user_id=".$member[$i];
    	$content[$i] = file_get_contents($website[$i]);
    	$update[$i] = json_decode($content[$i], TRUE);
        $message[$i] = $update[$i]["result"]["user"]["username"];
        echo "@".$message[$i]."<br>";
    }
?>