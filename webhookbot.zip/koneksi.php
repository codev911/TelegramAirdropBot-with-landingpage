<?php
$conn = mysqli_connect('localhost','levyteco_airdrop','B@?ttlp$3!4V','levyteco_airdropbot');
if(!$conn) {
    exit("Error: ".mysqli_connect_error());
}
?>