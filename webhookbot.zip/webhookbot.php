<?php
    require_once('koneksi.php');
    error_reporting(0);
    ini_set('display_errors', 0);
    $groupchat = -1001270693075;
	$botToken = "772748111:AAGYJokeHu0OFCRVFn2Wt6g8STMvCC62Lmg";
	$website = "https://api.telegram.org/bot".$botToken;
	$content = file_get_contents("php://input");
	$update = json_decode($content, TRUE);
    $message = $update["message"];
    $message_id = $message["message_id"];
    $chatId = $message["chat"]["id"];
    $fromid = $message["from"]["id"];
    $chattype = $message["chat"]["type"];
    $text = $message["text"];
	$jawab;
	$getcontents;
	if (isset($text)) {
	    if (strpos($text,"/confirm") !== false) {
	        similar_text("/confirm",$text,$percent);
	        if($percent == 100){
	           $jawab = "Make sure you registered on airdrop page.";
	        }else if($chattype == "private" || $chatId != $groupchat){
	            $jawab = "Make sure you join and confirm on our official telegram group and telegram channel.";
	        }else{
	            global $conn;
	            $string = explode(" ",$text);
                $reff = (string) $string['1'];
                $query = "SELECT * FROM user WHERE reff_id='$reff'";
                $query = mysqli_query($conn, $query);
                $rowlook = mysqli_num_rows($query);
                if($rowlook == 0){
                     $jawab = "Incorrect code, make sure you copied it from airdrop page correctly";
                }else{
                    global $conn;
                    $query = "SELECT * FROM activation WHERE telegram_id = '$fromid'";
                    $query = mysqli_query($conn, $query);
                    $counter = mysqli_num_rows($query);
                    if($counter > 0){
                        $jawab = "This telegram already used other account.";
                    }else{
                        global $conn;
                        $jawab = "Your airdrop is confirmed and you received 22222 LEVT on airdrop page, dont forget donation to get more LEVT, check at pinned post for more info.";
                    
                        $query = "INSERT INTO activation VALUES('$reff',CURRENT_TIMESTAMP,'$fromid')";
                        mysqli_query($conn, $query);
                    }
                    
                }
	        }
        } 
	}
	$getcontents = $website."/sendmessage?chat_id=".$chatId."&text=".urlencode($jawab)."&parse_mode=Markdown&reply_to_message_id=".$message_id;
	file_get_contents($getcontents);
?>